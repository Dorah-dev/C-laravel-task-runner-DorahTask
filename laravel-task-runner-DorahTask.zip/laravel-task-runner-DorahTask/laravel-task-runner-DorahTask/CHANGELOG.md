# Changelog

All notable changes to `laravel-task-runner` will be documented in this file.

## 1.4.1 - 2024-11-14

**Full Changelog**: https://github.com/dorahtask/laravel-task-runner/compare/1.4.0...1.4.1

## 1.4.0 - 2024-11-14

* Connection config improvements
* Laravel 11 support
* Dropped PHP 8.1 support



**Full Changelog**: https://github.com/dorahtask/laravel-task-runner/compare/1.2.0...1.3.0


