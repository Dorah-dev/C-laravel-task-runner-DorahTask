<?php

namespace DorahTask\LaravelTaskRunner\Facades;

use Illuminate\Support\Facades\Facade;
use DorahTask\LaravelTaskRunner\PendingTask;
use DorahTask\LaravelTaskRunner\ProcessOutput;
use DorahTask\LaravelTaskRunner\TaskDispatcher;

/**
 * @method static self assertDispatched(string|callable $taskClass, callable $additionalCallback = null)
 * @method static self assertDispatchedTimes(string|callable $taskClass, int $times = 1, callable $additionalCallback = null)
 * @method static self assertNotDispatched(string|callable $taskClass, callable $additionalCallback = null)
 * @method static self fake(array|string $tasksToFake = [])
 * @method static self dontFake(array|string $taskToDispatch)
 * @method static self preventStrayTasks(bool $prevent = true)
 * @method static ProcessOutput|null run(PendingTask $pendingTask)
 *
 * @see \DorahTask\LaravelTaskRunner\TaskDispatcher
 */
class TaskRunner extends Facade
{
    protected static function getFacadeAccessor()
    {
        return TaskDispatcher::class;
    }
}
