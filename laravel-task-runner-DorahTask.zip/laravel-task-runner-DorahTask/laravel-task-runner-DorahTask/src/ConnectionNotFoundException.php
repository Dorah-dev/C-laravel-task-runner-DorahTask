<?php

namespace DorahTask\LaravelTaskRunner;

use Exception;

class ConnectionNotFoundException extends Exception
{
}
