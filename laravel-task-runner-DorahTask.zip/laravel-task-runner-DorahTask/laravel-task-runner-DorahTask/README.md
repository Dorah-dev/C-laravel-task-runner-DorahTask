# Laravel Task Runner

A package to write Shell scripts like Blade Components and run them locally or on a remote server. Support for running tasks in the background and test assertions. Built upon the [Process feature](https://laravel.com/docs/10.x/processes) in Laravel 10.



## Installation

This package requires Laravel 10 and PHP 8.2 or higher. You can install the package via composer:

```bash
composer require dorahtask/laravel-task-runner
```

Optionally, you can publish the config file with:

```bash
php artisan vendor:publish --provider="dorahtask\LaravelTaskRunner\ServiceProvider"
```

## Basic usage

You may use the Artisan `make:task` command to create a `Task` class:

```bash
php artisan make:task ComposerGlobalUpdate
```

This will generate two files: `app/Tasks/ComposerGlobalUpdate.php` and `resources/views/tasks/composer-global-update.blade.php`.

Once you've added your script to the Blade template, you may run it on your local machine by calling the `dispatch()` method:

```php
ComposerGlobalUpdate::dispatch();
```

Alternatively, if you don't want a separate Blade template, you may use the `--class` option (or `-c`):

```bash
php artisan make:task ComposerGlobalUpdate -c
```

This allows you to specify the script inline:

```php
class ComposerGlobalUpdate extends Task
{
    public function render(): string
    {
        return 'composer global update';
    }
}
```

## Task output

The `dispatch()` method returns an instance of `ProcessOutput`, which can return the output and exit code:

```php
$output = ComposerGlobalUpdate::dispatch();

$output->getBuffer();
$output->getExitCode();

$output->getLines();    // returns the buffer as an array
$output->isSuccessful();    // returns true when the exit code is 0
$output->isTimeout();    // returns true on a timeout
```

To interact with the underlying `ProcessResult`, you may call the `getIlluminateResult()` method:

```php
$output->getIlluminateResult();
```

## Script variables

Just like Blade Components, the public properties and methods of the Task class are available in the template:

```php
class GetFile extends Task
{
    public function __construct(public string $path)
    {
    }

    public function options()
    {
        return '-n';
    }
}
```

Blade template:

```blade
cat {{ $options() }} {{ $path }}
```

You can create a new instance of the Task using the static `make()` method:

```php
GetFile::make('/etc/hosts')->dispatch();
```

## Task options

You may specify a timeout. By default, the timeout is based on the `task-runner.default_timeout` config value.

```php
class ComposerGlobalUpdate extends Task
{
    protected int $timeout = 60;
}
```

## Run in background

You may run a task in the background:

```php
ComposerGlobalUpdate::inBackground()->dispatch();
```

It allows you to write the output to a file, as the `dispatch()` method won't return anything when the Task is still running in the background.

```php
ComposerGlobalUpdate::inBackground()
    ->writeOutputTo(storage_path('script.output'))
    ->dispatch();
```

## Run tasks on a remote server

In the `task-runner` configuration file, you may specify one or more remote servers:

```php
return [
    'connections' => [
        // 'production' => [
        //     'host' => '',
        //     'port' => '',
        //     'username' => '',
        //     'private_key' => '',
        //     'private_key_path' => '',
        //     'passphrase' => '',
        //     'script_path' => '',
        // ],
    ],
];
```

Now you may call the `onConnection()` method before calling other methods:

```php
ComposerGlobalUpdate::onConnection('production')->dispatch();

ComposerGlobalUpdate::onConnection('production')->inBackground()->dispatch();
```

## Task test assertions

You may call the `fake()` method to prevent tasks from running and make assertions after acting:

```php
use DorahTask\LaravelTaskRunner\Facades\TaskRunner;

/** @test */
public function it_updates_composer_globally()
{
    TaskRunner::fake();

    $this->post('/api/composer/global-update');

    TaskRunner::assertDispatched(ComposerGlobalUpdate::class);
}
```

You may also use a callback to investigate the Task further:

```php
TaskRunner::assertDispatched(function (ComposerGlobalUpdate $task) {
    return $task->foo === 'bar';
});
```

If you type-hint the Task with `PendingTask`, you may verify the configuration:

```php
use DorahTask\LaravelTaskRunner\PendingTask;

TaskRunner::assertDispatched(ComposerGlobalUpdate::class, function (PendingTask $task) {
    return $task->shouldRunInBackground();
});

TaskRunner::assertDispatched(ComposerGlobalUpdate::class, function (PendingTask $task) {
    return $task->shouldRunOnConnection('production');
});
```

To fake just some of the tasks, you may call the `fake()` method with a class or array of classes:

```php
TaskRunner::fake(ComposerGlobalUpdate::class);
TaskRunner::fake([ComposerGlobalUpdate::class]);
```

Alternatively, you may fake everything except a specific task:

```php
TaskRunner::fake()->dontFake(ComposerGlobalUpdate::class);
```

You may also supply a fake Task output:

```php
TaskRunner::fake([
    ComposerGlobalUpdate::class => 'Updating dependencies'
]);
```

Or use the `ProcessOutput` class to set the exit code as well:

```php
use DorahTask\LaravelTaskRunner\ProcessOutput;

TaskRunner::fake([
    ComposerGlobalUpdate::class => ProcessOutput::make('Updating dependencies')->setExitCode(1);
]);
```

When you specify the Task output, you may also prevent unlisted Tasks from running:

```php
TaskRunner::preventStrayTasks();
```

## Changelog

Please see [CHANGELOG](CHANGELOG.md) for more information what has changed recently.

## Contributing

Please see [CONTRIBUTING](CONTRIBUTING.md) for details.



Installation
This package requires Laravel 10 and PHP 8.2 or higher. You can install the package via composer:

composer require dorahtask/laravel-task-runner
Optionally, you can publish the config file with:

php artisan vendor:publish --provider="DorahTask\LaravelTaskRunner\ServiceProvider"
Basic usage
You may use the Artisan make:task command to create a Task class:

php artisan make:task ComposerGlobalUpdate
This will generate two files: app/Tasks/ComposerGlobalUpdate.php and resources/views/tasks/composer-global-update.blade.php.

Once you've added your script to the Blade template, you may run it on your local machine by calling the dispatch() method:

ComposerGlobalUpdate::dispatch();
Alternatively, if you don't want a separate Blade template, you may use the --class option (or -c):

php artisan make:task ComposerGlobalUpdate -c
This allows you to specify the script inline:

class ComposerGlobalUpdate extends Task
{
    public function render(): string
    {
        return 'composer global update';
    }
}
Task output
The dispatch() method returns an instance of ProcessOutput, which can return the output and exit code:

$output = ComposerGlobalUpdate::dispatch();

$output->getBuffer();
$output->getExitCode();

$output->getLines();    // returns the buffer as an array
$output->isSuccessful();    // returns true when the exit code is 0
$output->isTimeout();    // returns true on a timeout
To interact with the underlying ProcessResult, you may call the getIlluminateResult() method:

$output->getIlluminateResult();
Script variables
Just like Blade Components, the public properties and methods of the Task class are available in the template:

class GetFile extends Task
{
    public function __construct(public string $path)
    {
    }

    public function options()
    {
        return '-n';
    }
}
Blade template:

cat {{ $options() }} {{ $path }}
You can create a new instance of the Task using the static make() method:

GetFile::make('/etc/hosts')->dispatch();
Task options
You may specify a timeout. By default, the timeout is based on the task-runner.default_timeout config value.

class ComposerGlobalUpdate extends Task
{
    protected int $timeout = 60;
}
Run in background
You may run a task in the background:

ComposerGlobalUpdate::inBackground()->dispatch();
It allows you to write the output to a file, as the dispatch() method won't return anything when the Task is still running in the background.

ComposerGlobalUpdate::inBackground()
    ->writeOutputTo(storage_path('script.output'))
    ->dispatch();
Run tasks on a remote server
In the task-runner configuration file, you may specify one or more remote servers:

return [
    'connections' => [
        // 'production' => [
        //     'host' => '',
        //     'port' => '',
        //     'username' => '',
        //     'private_key' => '',
        //     'private_key_path' => '',
        //     'passphrase' => '',
        //     'script_path' => '',
        // ],
    ],
];
Now you may call the onConnection() method before calling other methods:

ComposerGlobalUpdate::onConnection('production')->dispatch();

ComposerGlobalUpdate::onConnection('production')->inBackground()->dispatch();
Task test assertions
You may call the fake() method to prevent tasks from running and make assertions after acting:

use DorahTask\LaravelTaskRunner\Facades\TaskRunner;

/** @test */
public function it_updates_composer_globally()
{
    TaskRunner::fake();
 $this->post('/api/composer/global-update');

    TaskRunner::assertDispatched(ComposerGlobalUpdate::class);
}
You may also use a callback to investigate the Task further:

TaskRunner::assertDispatched(function (ComposerGlobalUpdate $task) {
    return $task->foo === 'bar';
});
If you type-hint the Task with PendingTask, you may verify the configuration:

use DorahTask\LaravelTaskRunner\PendingTask;

TaskRunner::assertDispatched(ComposerGlobalUpdate::class, function (PendingTask $task) {
    return $task->shouldRunInBackground();
});

TaskRunner::assertDispatched(ComposerGlobalUpdate::class, function (PendingTask $task) {
    return $task->shouldRunOnConnection('production');
});
To fake just some of the tasks, you may call the fake() method with a class or array of classes:

TaskRunner::fake(ComposerGlobalUpdate::class);
TaskRunner::fake([ComposerGlobalUpdate::class]);
Alternatively, you may fake everything except a specific task:

TaskRunner::fake()->dontFake(ComposerGlobalUpdate::class);
You may also supply a fake Task output:

TaskRunner::fake([
    ComposerGlobalUpdate::class => 'Updating dependencies'
]);
Or use the ProcessOutput class to set the exit code as well:

use DorahTask\LaravelTaskRunner\ProcessOutput;

TaskRunner::fake([
    ComposerGlobalUpdate::class => ProcessOutput::make('Updating dependencies')->setExitCode(1);
]);
When you specify the Task output, you may also prevent unlisted Tasks from running:

TaskRunner::preventStrayTasks();
